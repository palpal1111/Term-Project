from django.urls import path
from . import views

urlpatterns = [
    path("", views.QuizView, name="quizPage"),
    path("score/", views.score, name="scorePage"),
    path("start_quiz/", views.start_quiz, name="startQuiz"),
    path("result/", views.get_performance_message, name="result"),
    
    
]

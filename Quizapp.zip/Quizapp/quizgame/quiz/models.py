from django.db import models
from user.models import CustomUser

# Create your models here.
from django.db import models
from django.contrib.auth.models import User

class Question(models.Model):
    question = models.CharField(max_length=200)
    correct_answer = models.CharField(max_length=100)
    wrong_answer1 = models.CharField(max_length=100)
    wrong_answer2 = models.CharField(max_length=100)
    wrong_answer3 = models.CharField(max_length=100)

    def __str__(self):
        return self.question

class Quiz(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    questions = models.ManyToManyField(Question)
    score = models.IntegerField()
    date_taken = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Quiz {self.id} - User: {self.user.full_name}, Score: {self.score}"

class QuizResult(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE)
    percentage = models.IntegerField()
    performance_message = models.CharField(max_length=100, default="")
    date_taken = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"QuizResult - User: {self.user.full_name}, Quiz: {self.quiz}, Percentage: {self.percentage}"

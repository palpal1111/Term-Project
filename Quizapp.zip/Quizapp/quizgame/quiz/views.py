from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import QuizResult, Question, Quiz
import random
from decimal import Decimal
from django.db.models import Avg, Max, Min

def start_quiz(request):
    if request.method == 'POST':
        user = request.user
        questions = Question.objects.all()  # Get all questions
        score = 0

        # Calculate the score based on the user's answers
        for question in questions:
            user_answer = request.POST.get(f'question_{question.id}')
            if user_answer == question.correct_answer:
                score += 1

        percentage = (Decimal(score) / 5) * 100  # Convert score to Decimal to ensure float division

        performance_message = get_performance_message(percentage)

        # Save the quiz result to the database
        quiz = Quiz.objects.create(user=user, score=score)
        QuizResult.objects.create(user=user, quiz=quiz, percentage=percentage, performance_message=performance_message)

        # Display the quiz result to the user
        context = {
            'questions': questions,
            'score': score,
            'percentage': percentage,
            'performance_message': performance_message
        }
        return render(request, 'quiz_result.html', context)
    else:
        questions = Question.objects.order_by('?')[:5]  # Select 5 random questions
        for question in questions:
            answers = [question.correct_answer, question.wrong_answer1, question.wrong_answer2, question.wrong_answer3]
            random.shuffle(answers)
            question.answers = answers  # Store shuffled answers as a new attribute in the question object

        return render(request, 'start_quiz.html', {'questions': questions})
    
    
@login_required
def score(request):
    # Get all quiz results of the logged-in user
    quiz_results = QuizResult.objects.filter(user=request.user)

    return render(request, 'score.html', {'quiz_results': quiz_results})

def get_performance_message(percentage):
    if percentage == 100:
        return "You are a genius!"
    elif percentage >= 50:
        return "Congratulations!"
    else:
        return "Please try again!"

# Create your views here.
@login_required(login_url='/auth/login')
def QuizView(request):
    user = request.user
    quiz_results = Quiz.objects.filter(user=request.user)

    # Calculate the average, highest, and lowest scores
    average_score = quiz_results.aggregate(Avg('score'))['score__avg']
    highest_score = quiz_results.aggregate(Max('score'))['score__max']
    lowest_score = quiz_results.aggregate(Min('score'))['score__min']
    
    context = {
        'user': user,
        'average_score': average_score,
        'highest_score': highest_score,
        'lowest_score': lowest_score,
    }
    return render(request, 'quiz.html', context )
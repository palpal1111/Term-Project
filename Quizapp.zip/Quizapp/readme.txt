1. Go inside Quizapp in cmd and activate virtual env.
	env\Scripts\activate

2. After go inside myproject folder and runserver
	python manage.py runserver

3. Visit https://localhost:8000

4. admin login is username : test@gmail.com , password : test

if step 4 doesn't work then
before running server
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser // this will create admin login access
